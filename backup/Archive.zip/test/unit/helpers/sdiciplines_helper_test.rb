require 'test_helper'

class SdiciplinesHelperTest < ActionView::TestCase
end
