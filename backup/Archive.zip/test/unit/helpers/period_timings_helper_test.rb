require 'test_helper'

class PeriodTimingsHelperTest < ActionView::TestCase
end
