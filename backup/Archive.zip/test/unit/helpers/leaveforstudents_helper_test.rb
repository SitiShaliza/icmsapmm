require 'test_helper'

class LeaveforstudentsHelperTest < ActionView::TestCase
end
