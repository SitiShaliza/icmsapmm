require 'test_helper'

class KlassesHelperTest < ActionView::TestCase
end
