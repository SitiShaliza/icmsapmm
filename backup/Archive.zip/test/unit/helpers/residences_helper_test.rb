require 'test_helper'

class ResidencesHelperTest < ActionView::TestCase
end
