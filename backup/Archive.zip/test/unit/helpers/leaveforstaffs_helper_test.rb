require 'test_helper'

class LeaveforstaffsHelperTest < ActionView::TestCase
end
