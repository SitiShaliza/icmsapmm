require 'test_helper'

class UsesuppliesHelperTest < ActionView::TestCase
end
