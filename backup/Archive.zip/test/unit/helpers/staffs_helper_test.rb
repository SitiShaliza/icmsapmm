require 'test_helper'

class StaffsHelperTest < ActionView::TestCase
end
