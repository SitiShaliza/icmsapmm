require 'test_helper'

class EvactivitiesHelperTest < ActionView::TestCase
end
