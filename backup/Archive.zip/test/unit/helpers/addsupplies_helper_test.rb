require 'test_helper'

class AddsuppliesHelperTest < ActionView::TestCase
end
