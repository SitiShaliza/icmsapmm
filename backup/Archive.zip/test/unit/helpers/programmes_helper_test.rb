require 'test_helper'

class ProgrammesHelperTest < ActionView::TestCase
end
