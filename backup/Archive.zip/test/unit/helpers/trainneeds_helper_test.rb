require 'test_helper'

class TrainneedsHelperTest < ActionView::TestCase
end
