require 'test_helper'

class TravelrequestsHelperTest < ActionView::TestCase
end
