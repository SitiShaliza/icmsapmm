require 'test_helper'

class StafftitlesHelperTest < ActionView::TestCase
end
