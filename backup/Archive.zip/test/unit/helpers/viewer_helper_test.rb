require 'test_helper'

class ViewerHelperTest < ActionView::TestCase
end
