require 'test_helper'

class TimetablesHelperTest < ActionView::TestCase
end
