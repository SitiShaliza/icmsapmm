require 'test_helper'

class AssetlossesHelperTest < ActionView::TestCase
end
