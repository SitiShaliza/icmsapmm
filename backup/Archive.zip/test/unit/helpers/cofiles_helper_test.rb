require 'test_helper'

class CofilesHelperTest < ActionView::TestCase
end
