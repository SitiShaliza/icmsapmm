require 'test_helper'

class PartsHelperTest < ActionView::TestCase
end
