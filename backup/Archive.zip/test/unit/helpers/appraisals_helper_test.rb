require 'test_helper'

class AppraisalsHelperTest < ActionView::TestCase
end
