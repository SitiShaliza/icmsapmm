require 'test_helper'

class AssetnumsHelperTest < ActionView::TestCase
end
