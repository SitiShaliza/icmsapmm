require 'test_helper'

class AttendancesHelperTest < ActionView::TestCase
end
