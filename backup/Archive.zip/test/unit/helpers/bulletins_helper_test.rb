require 'test_helper'

class BulletinsHelperTest < ActionView::TestCase
end
