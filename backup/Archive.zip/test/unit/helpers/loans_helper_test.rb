require 'test_helper'

class LoansHelperTest < ActionView::TestCase
end
