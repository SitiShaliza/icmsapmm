require 'test_helper'

class StudentleavesHelperTest < ActionView::TestCase
end
