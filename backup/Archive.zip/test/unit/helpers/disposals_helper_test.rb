require 'test_helper'

class DisposalsHelperTest < ActionView::TestCase
end
