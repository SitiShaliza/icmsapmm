require 'test_helper'

class CurriculumsHelperTest < ActionView::TestCase
end
