require 'test_helper'

class ExamquestionsHelperTest < ActionView::TestCase
end
