require 'test_helper'

class IntakesHelperTest < ActionView::TestCase
end
