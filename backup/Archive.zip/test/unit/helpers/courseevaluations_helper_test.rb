require 'test_helper'

class CourseevaluationsHelperTest < ActionView::TestCase
end
