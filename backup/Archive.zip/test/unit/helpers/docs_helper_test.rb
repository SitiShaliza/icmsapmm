require 'test_helper'

class DocsHelperTest < ActionView::TestCase
end
