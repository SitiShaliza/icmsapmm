require 'test_helper'

class LeavesHelperTest < ActionView::TestCase
end
