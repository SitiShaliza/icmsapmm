require 'test_helper'

class TimeTableEntriesHelperTest < ActionView::TestCase
end
