require 'test_helper'

class StrainingsHelperTest < ActionView::TestCase
end
