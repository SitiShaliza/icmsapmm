require 'test_helper'

class PositionsHelperTest < ActionView::TestCase
end
