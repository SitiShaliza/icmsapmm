require 'test_helper'

class CounsellingsHelperTest < ActionView::TestCase
end
