require 'test_helper'

class StaffcoursesHelperTest < ActionView::TestCase
end
