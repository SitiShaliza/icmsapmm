require 'test_helper'

class TravelclaimsHelperTest < ActionView::TestCase
end
