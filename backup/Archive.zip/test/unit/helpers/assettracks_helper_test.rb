require 'test_helper'

class AssettracksHelperTest < ActionView::TestCase
end
