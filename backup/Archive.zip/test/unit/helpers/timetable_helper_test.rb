require 'test_helper'

class TimetableHelperTest < ActionView::TestCase
end
