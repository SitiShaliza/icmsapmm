require 'test_helper'

class StudentLeavesHelperTest < ActionView::TestCase
end
