require 'test_helper'

class MaintsHelperTest < ActionView::TestCase
end
