require 'test_helper'

class TitlesHelperTest < ActionView::TestCase
end
