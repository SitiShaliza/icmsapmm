require 'test_helper'

class AddbooksHelperTest < ActionView::TestCase
end
