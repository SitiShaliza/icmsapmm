require 'test_helper'

class SuppliesHelperTest < ActionView::TestCase
end
