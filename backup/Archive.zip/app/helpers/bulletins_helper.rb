module BulletinsHelper
  
 
end
