module IntakesHelper
end
