I18n.default_locale = 'ms_MY'

LOCALES_DIRECTORY = "#{RAILS_ROOT}/config/locales/"

LANGUAGES = {
  'English' => 'en',
  'Bahasa Malaysia' => 'ms_MY'
}
