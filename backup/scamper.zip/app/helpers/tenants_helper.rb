module TenantsHelper
end
