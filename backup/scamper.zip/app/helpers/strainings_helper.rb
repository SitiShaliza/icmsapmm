module StrainingsHelper
end
